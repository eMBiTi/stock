
__**How To Use**__
> Open Folder

> Run it manually by opening a cmd in the path you saved it. And when it opens type in `python main.py`

> Add your Pm Tokens in `tokens.txt`

> Run the tool

> Select the nitro type and duration

> IF you hit some nitros it will be saved in `nitros.txt`


__**Requirments**__

> Python (Last Version)

__**In cmd type this**__

>pip install colorama

>pip install tasksio

>pip install aiohttp

>pip install asyncio

>pip install logging

>pip install sys

>pip install os

That's all